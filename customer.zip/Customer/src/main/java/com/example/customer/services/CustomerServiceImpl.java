package com.example.customer.services;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.customer.entiy.Customer;
import com.example.customer.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements  CustomerServices{
	@Autowired
	CustomerRepository cr1;
	@Override
	public Customer saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return cr1.save(customer);
	}
	@Override
    public List<Customer> fetchCustomerList() {
        return cr1.findAll();
    }

   @Override
   public Customer fetchCustomerById(Long customerid) {
	   return cr1.findById(customerid).get();
   }
	
   @Override
   public void deleteCustomerById(Long customerid) {
       cr1.deleteById(customerid);
   }


   @Override
   public Customer updateCustomer(Long customerid, Customer customer) {
	   Customer depDB = cr1.findById(customerid).get();

       if(Objects.nonNull(customer.getCustomerName()) &&
       !"".equalsIgnoreCase(customer.getCustomerName())) {
           depDB.setCustomerName(customer.getCustomerName());
       }

       if(Objects.nonNull(customer.getCustomerEmail()) &&
               !"".equalsIgnoreCase(customer.getCustomerEmail())) {
           depDB.setCustomerEmail(customer.getCustomerEmail());
       }
       if(Objects.nonNull(customer.getCustomerPhone()) &&
               !longValue(customer.getCustomerPhone())) {
           depDB.setCustomerPhone(customer.getCustomerPhone());
       }
              
       return cr1.save(depDB);
   }
private boolean longValue(long customerPhone) {
	// TODO Auto-generated method stub
	return false;
}

    
    

}



