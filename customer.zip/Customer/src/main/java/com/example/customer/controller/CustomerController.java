package com.example.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.customer.entiy.Customer;
import com.example.customer.services.CustomerServices;

@RestController
public class CustomerController {
	@Autowired
	CustomerServices cs1;
	@PostMapping("/customers")
	public Customer saveCustomer(@RequestBody Customer customer) {
		
		return cs1.saveCustomer(customer);
	}
		@GetMapping("/customers") 
		public List<Customer> fetchcustomerList() {
	        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
	        return cs1.fetchCustomerList();
	    }
		@DeleteMapping("/customers/{id}")
	    public String deleteCustomerById(@PathVariable("id") Long customerid) {
	        cs1.deleteCustomerById(customerid);
	        return "Department deleted Successfully!!";
	    }
	    
	    @PutMapping("/customers/{id}")
	    public Customer updateCustomer(@PathVariable("id") Long customerid,
	                                       @RequestBody Customer customer) {
	        return cs1.updateCustomer(customerid, customer);
	    }
	}

